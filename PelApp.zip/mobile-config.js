App.info({
  name: 'PelApp',
  description: 'PelApp',
  version: '0.0.1'
});

App.icons({
  'android_ldpi': 'public/icon.png',
  'android_mdpi': 'public/icon.png',
  'android_hdpi': 'public/icon.png',
  'android_xhdpi': 'public/icon.png'
});