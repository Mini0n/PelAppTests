Meteor.publish('definitions', function(){
  return Definitions.find();
});