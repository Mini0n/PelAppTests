Template.definitionItem.helpers({
  //*helper functions here*
});