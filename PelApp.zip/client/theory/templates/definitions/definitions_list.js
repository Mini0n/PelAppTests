// var definitionsData = [
//   {
//     name: 'Cirugía',
//     text: 'Kheir - mano Ergon - trabajo\n \"Trabajo manual\" \nPráctica que implica la manipulación mecánica de las estructuras anatómicas con un fin médico, ya sea diagnóstico, terapéutico o pronóstico.',
//     url: '/'
//   },
//   {
//     name:'Lipoma',
//     text: 'Tumor benigno costituido por la proliferación del tejido celular subcutáneo.',
//     url: '/'
//   }
// ];


Template.definitionsList.helpers({
  // definitions: definitionsData
  definitions: function(){
    return Definitions.find();
  }
});