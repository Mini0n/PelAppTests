//Queue de secciones visitadas
// visitedSections = [];

//Definciones médicas
Meteor.subscribe('definitions');


/* Disables hot code push */
// Meteor._reload.onMigrate(function() {
//   return [false];
// });





